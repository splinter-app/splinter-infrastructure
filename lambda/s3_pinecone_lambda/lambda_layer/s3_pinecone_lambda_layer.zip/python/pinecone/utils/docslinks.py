docslinks = {
    "GITHUB_REPO": "https://github.com/pinecone-io/pinecone-python-client",
    "LANGCHAIN_IMPORT_KB_ARTICLE": "https://docs.pinecone.io/troubleshooting/pinecone-attribute-errors-with-langchain",
}

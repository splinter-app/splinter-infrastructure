# do not import all apis into this module because that uses a lot of memory and stack frames
# if you need the ability to import all apis from one package, import them with
# from pinecone.core.openapi.control.apis import InferenceApi
